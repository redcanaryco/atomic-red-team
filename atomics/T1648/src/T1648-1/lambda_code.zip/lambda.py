def lambda_handler(event, context):
    return "This is a benign lambda function"
