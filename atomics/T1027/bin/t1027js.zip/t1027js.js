// Launches calculator via WScript

var shell = new ActiveXObject("WScript.Shell");
shell.Run("calc.exe");